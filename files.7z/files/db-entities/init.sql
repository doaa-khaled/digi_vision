CREATE TABLE IF NOT EXISTS item (
    id SERIAL PRIMARY KEY,
    typeI VARCHAR(100) NOT NULL,
    name VARCHAR(100) NOT NULL,
	parentId int
	permissionGroupId int,
    constraint fk_permission_group_id FOREIGN KEY (permissionGroupId) REFERENCES permissionGroup (id)
);
CREATE TABLE IF NOT EXISTS file (
    id SERIAL PRIMARY KEY,
    binaryD bytea,
	itemId int,
    constraint fk_item_id FOREIGN KEY (itemId) REFERENCES item (id)
);
CREATE TABLE IF NOT EXISTS permission (
    id SERIAL PRIMARY KEY,
    permissionLevel VARCHAR(100) NOT NULL,
    userEmail VARCHAR(100) NOT NULL,
	permissionGroupId int,
    constraint fk_permission_group_id FOREIGN KEY (permissionGroupId) REFERENCES permissionGroup (id)
);
CREATE TABLE IF NOT EXISTS permissionGroup (
    id SERIAL PRIMARY KEY,
    groupName VARCHAR(100) NOT NULL
);